# ujo-music

Super simple website using webpack & a lot of HTML.

To get started, simply install
```
npm i webpack-dev-server -g
```
and
```
npm i webpack -g
```

Now, to start developing, run `webpack-dev-server`.

To compile for production, run `webpack`

The folder structure is simple:
```
- index.html -- most of the site
- index.js -- some javascript
- sass -- we are using sass for the styles 
```

That's about it!
